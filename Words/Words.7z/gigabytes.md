**giga-**
(ˈɡɪɡə, ˈɡaɪɡə)
1. denoting $10^9$
Symbol: **G**
2. (in computer technology) denoting $2^{30}$
**gigabyte**
