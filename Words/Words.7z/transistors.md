**transistor**  (trænˈzɪstə)
**NOUN**
a semiconductor device, having three or more terminals attached to electrode regions, in which current flowing between two electrodes is controlled by a voltage or current applied to one or more specified electrodes. 
The device is capable of amplification, etc, and has replaced the valve in most circuits since it is much smaller, more robust, and works at a much lower voltage See also junction transistor, field-effect transistor