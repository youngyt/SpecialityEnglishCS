**decimal**
(desɪməl)
ADJECTIVE [ADJECTIVE noun]

A decimal system involves counting in units of ten.

*...the decimal system of metric weights and measures.  *

*In 1971, the 1p and 2p decimal coins were introduced in Britain.*