---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["incomprehensible"]
---

# incomprehensible

## 发音

- ɪnˌkɒmprɪˈhensəbl
- ɪnˌkɑmprɪˈhensəbl

## 词义

### ADJ-GRADED

Something that is incomprehensible is impossible to understand.  

> Her speech was almost incomprehensible.



## 


