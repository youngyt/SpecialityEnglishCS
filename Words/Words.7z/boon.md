**boon** (bun)
**COUNTABLE NOUN**

You can describe something as a boon when it makes life better or easier for someone.

- _It is for this reason that television proves such a boon to so many people._