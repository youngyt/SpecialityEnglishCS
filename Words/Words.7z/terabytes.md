**tera-**
1. denoting $10^{12}$
Symbol: **T**
2. (in computer technology) denoting $2^{40}$
**terabyte**
