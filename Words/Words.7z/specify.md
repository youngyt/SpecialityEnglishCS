---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["specify"]
---

# specify

## 发音

- ˈspesɪfaɪ
- ˈspɛsəˌfaɪ

## 词义

### VERB

If you specify something, you give information about what is required or should happen in a certain situation.  

> They specified a spacious entrance hall...

### VERB

If you specify what should happen or be done, you explain it in an exact and detailed way.  

> Each recipe specifies the size of egg to be used...



## 


