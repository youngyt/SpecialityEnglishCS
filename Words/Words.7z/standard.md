---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["standard"]
---

# standard

## 发音

- ˈstændəd
- ˈstændərd

## 词义

### N-COUNT

A standard is a level of quality or achievement, especially a level that is thought to be acceptable.  

> The standard of professional cricket has never been lower...

### N-COUNT

A standard is something that you use in order to judge the quality of something else.  

> ...systems that were by later standards absurdly primitive.

### N-PLURAL

See also:double standard;Standards are moral principles which affect people's attitudes and behaviour.  

> My father has always had high moral standards.

### ADJ-GRADED

You use standard to describe things which are usual and normal.  

> It was standard practice for untrained clerks to advise in serious cases such as murder...

### ADJ

A standard work or text on a particular subject is one that is widely read and often recommended.  



## 


