**equation** (iˈkweɪʒən ; ɪˈkweɪʒən)

**countable noun**

An equation is a situation in which two or more parts have to be considered together so that the whole situation can be understood or explained.

_The equation is simple: research breeds new products._