**statement**  /steɪtmənt/ 

statements, statementing, statemented

N-COUNTA **statement** is something that you say or write which gives information in a formal or definite way.

-   *Andrew now disowns that statement, saying he was depressed when he made it.*