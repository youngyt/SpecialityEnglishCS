**apart** (əˈpɑrt)

**Adverb**

You use apart when you are making an exception to a general statement.

_This was, New York apart, the first American city I had ever been in where people actually lived downtown._