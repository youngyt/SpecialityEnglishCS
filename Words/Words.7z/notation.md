**notation**
(noʊteɪʃən)
VARIABLE NOUN
A system of notation is a set of written symbols that are used to represent something such as music or mathematics.
*Musical notation was conceived for the C major scale.*
