---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["encode"]
---

# encode

## 发音

- ɪnˈkəʊd
- ɪnˈkoʊd

## 词义

### VERB

If you encode a message or some information, you put it into a code or express it in a different form or system of language.  

> The two parties encode confidential data in a form that is not directly readable by the other party...



## 


