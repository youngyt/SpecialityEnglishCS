---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["tempo"]
---

# tempo

## 发音

- ˈtempəʊ
- ˈtempoʊ

## 词义

### N-SING

The tempo of an event is the speed at which it happens.  

> ...owing to the slow tempo of change in an overwhelmingly rural country...

### N-VAR

The tempo of a piece of music is the speed at which it is played.  

> In a new recording, the Boston Philharmonic tried the original tempo...



## 


