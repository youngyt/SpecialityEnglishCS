---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["orchestra"]
---

# orchestra

## 发音

- ˈɔ:kɪstrə
- ˈɔrkɪstrə

## 词义

### N-COUNT

See also:chamber orchestra;symphony orchestra;An orchestra is a large group of musicians who play a variety of different instruments together. Orchestras usually play classical music.  

> ...the Royal Liverpool Philharmonic Orchestra.

### N-SING

The orchestra or the orchestra seats in a theatre or concert hall are the seats on the ground floor directly in front of the stage.  



## 


