**mega-**
(ˈmɛgə)
1. denoting $10^6$
Symbol: **M**
2. (in computer technology) denoting $2^{20}$
**megabyte**