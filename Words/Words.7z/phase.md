---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["phase"]
---

# phase

## 发音

- feɪz
- fez

## 词义

### N-COUNT

A phase is a particular stage in a process or in the gradual development of something.  

> This autumn, 6000 residents will participate in the first phase of the project...

### VERB

If an action or change is phased over a period of time, it is done in stages.  

> The redundancies will be phased over two years.

### PHRASE

If two things are out of phase with each other, they are not working or happening together as they should. If two things are in phase, they are working or occurring together as they should.  

> The Skills Programme is out of phase with the rest of the curriculum.



## 


