---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["matrices"]
---

# matrices

## 发音

- ˈmeɪtrɪsi:z
- ˈmetrɪˌsiz, ˈmætrɪ-

## 词义

### N-VAR

Matrices is the plural of matrix.  



## 


