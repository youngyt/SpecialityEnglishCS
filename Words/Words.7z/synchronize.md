---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["synchronize"]
---

# synchronize

## 发音

- /ˈsɪŋ.kɹə.naɪːz/
- /ˈsɪŋ.kɹə.naɪz/


## 词义

### Verb

To cause two or more events or actions to happen at exactly the same time or same rate, or in a time-coordinated way.

---

To set (a clock or watch) to display the same time as another.

> We synchronized our watches and agreed to meet at four o'clock precisely.

---

To cause (a set of files, data, or settings) on one computer or device to be (and try to remain) the same as on another.

---

(of inanimate entities) To agree, be coordinated with, or complement well.

---

To coordinate or combine.



## 


