**Binary** (ˈbaɪnəri)

**uncountable noun**

Binary is the binary system of expressing numbers.

_The machine does the calculations in binary._