---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["interval"]
---

# interval

## 发音

- ˈɪntəvl
- ˈɪntərvl

## 词义

### N-COUNT

An interval between two events or dates is the period of time between them.  

> The ferry service has restarted after an interval of 12 years...

### N-COUNT

An interval during a film, concert, show, or game is a short break between two of the parts.  

> During the interval, wine was served...

### N-COUNT

In music, an interval is the difference in pitch between two musical notes.  

### PHRASE

If something happens at intervals, it happens several times with gaps or pauses in between.  

> She woke him for his medicines at intervals throughout the night.

### PHRASE

If things are placed at particular intervals, there are spaces of a particular size between them.  

> Several red and white barriers marked the road at intervals of about a mile...



## 


