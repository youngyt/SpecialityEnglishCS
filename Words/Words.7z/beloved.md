---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["beloved"]
---

# beloved

## 发音

- bɪˈlʌvd
- bɪˈlʌvɪd, -ˈlʌvd

## 词义

### ADJ-GRADED

A beloved person, thing, or place is one that you feel great affection for.  

> He lost his beloved wife last year...

### N-SING

Your beloved is the person that you love.  

> He takes his beloved into his arms.



## 


