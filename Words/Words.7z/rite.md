---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["rite"]
---

# rite

## 发音

- raɪt
- raɪt

## 词义

### N-COUNT

See also:last rites;A rite is a traditional ceremony that is carried out by a particular group or within a particular society.  

> Most traditional societies have transition rites at puberty.



## 


