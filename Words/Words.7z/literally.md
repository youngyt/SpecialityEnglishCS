**literally** (ˈlɪtərəli)

**Adverb**

1. You can use **literally** to emphasize a statement. Some careful speakers of English think that this use is incorrect.
_We've got to get the economy under control or it will literally eat us up._
2. If a word or expression is translated **literally**, its most simple or basic meaning is translated.
- _The word 'volk' translates literally as 'folk'._ 
volk 这个单词直译过来为 folk（人们）
