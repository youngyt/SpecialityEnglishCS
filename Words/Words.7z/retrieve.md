---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["retrieve"]
---

# retrieve

## 发音

- rɪˈtri:v
- rɪˈtriv

## 词义

### VERB

If you retrieve something, you get it back from the place where you left it.  

> He reached over and retrieved his jacket from the back seat...

### VERB

If you manage to retrieve a situation, you succeed in bringing it back into a more acceptable state.  

> He is the one man who could retrieve that situation.

### VERB

To retrieve information from a computer or from your memory means to get it back.  

> Computers can instantly retrieve millions of information bits...



## 


