**trillion**
(trɪljən)
**NUMBER**
A trillion is a million million.