---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["scheme"]
---

# scheme

## 发音

- ski:m
- skim

## 词义

### N-COUNT

A scheme is a plan or arrangement involving many people which is made by a government or other organization.  

> ...schemes to help combat unemployment.

### N-COUNT

A scheme is someone's plan for achieving something.  

> ...a quick money-making scheme to get us through the summer...

### VERB

If you say that people are scheming, you mean that they are making secret plans in order to gain something for themselves.  

> Everyone's always scheming and plotting... 

### PHRASE

Someone's scheme of things is the way in which they think that things in their life should be organized.  

> He did not quite know how to place women in his scheme of things.

### PHRASE

When people talk about the scheme of things or the grand scheme of things , they are referring to the way that everything in the world seems to be organized.  

> We realize that we are infinitely small within the scheme of things.



## 


