---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["universally"]
---

# universally

## 发音

- ˌju:nɪˈvɜ:səli
- ˌjunɪˈvɜrsəli

## 词义

### ADV

If something is universally believed or accepted, it is believed or accepted by everyone with no disagreement.  

> ...a universally accepted point of view...

### ADV

If something is universally true, it is true everywhere in the world or in all situations.  

> The disadvantage is that it is not universally available...



## 


