**unsurprisingly**(ˌʌnsəˈpraɪzɪŋlɪ)

**adverb**

in an unsurprising manner

_Unsurprisingly, not everyone agrees that things are better._