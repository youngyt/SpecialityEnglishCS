**minimize** (ˈmɪnɪˌmaɪz)

**Verb**

If you minimize a risk, problem, or unpleasant situation, you reduce it to the lowest possible level, or prevent it increasing beyond that level.

_Concerned people want to minimize the risk of developing cancer._