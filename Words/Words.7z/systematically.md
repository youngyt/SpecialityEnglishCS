**systematic** (ˌsɪstəˈmætɪk)

**Adjective**

Something that is done in a systematic way is done according to a fixed plan, in a thorough and efficient way.

_They went about their business in a systematic way._