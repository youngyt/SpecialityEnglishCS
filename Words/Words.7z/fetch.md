---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["fetch"]
---

# fetch

## 发音

- fetʃ
- fɛtʃ

## 词义

### VERB

If you fetch something or someone, you go and get them from the place where they are.  

> Sylvia fetched a towel from the bathroom...

### VERB

If something fetches a particular sum of money, it is sold for that amount.  

> The painting is expected to fetch between two and three million pounds.

### PHRASE

If you fetch and carry, you perform simple, often boring tasks for someone, such as collecting and carrying things for them.  

> I helped out in the tents fetching and carrying.



## 


