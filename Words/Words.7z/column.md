**column**
(kɒləm)
N-COUNT
A **column** is a group of people or animals which moves in a long line.
*There were reports of columns of military vehicles appearing on the streets.*