---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["sign"]
---

# sign

## 发音

- saɪn
- saɪn

## 词义

### N-COUNT

A sign is a mark or shape that always has a particular meaning, for example in mathematics or music.  

> Equations are generally written with a two-bar equals sign.

### N-COUNT

A sign is a movement of your arms, hands, or head which is intended to have a particular meaning.  

> They gave Lavalle the thumbs-up sign...

### VERB

If you sign, you communicate with someone using sign language. If a programme or performance is signed, someone uses sign language so that deaf people can understand it.  

> All programmes will be either 'signed' or subtitled...

### N-COUNT

A sign is a piece of wood, metal, or plastic with words or pictures on it. Signs give you information about something, or give you a warning or an instruction.  

> ...a sign saying that the highway was closed because of snow.

### N-VAR

If there is a sign of something, there is something which shows that it exists or is happening.  

> They are prepared to hand back a hundred prisoners of war a day as a sign of good will...

### VERB

When you sign a document, you write your name on it, usually at the end or in a special space. You do this to indicate that you have written the document, that you agree with what is written, or that you were present as a witness.  

> World leaders are expected to sign a treaty pledging to increase environmental protection...

### V-ERG

If an organization signs someone or if someone signs for an organization, they sign a contract agreeing to work for that organization for a specified period of time.  

> The Minnesota Vikings signed Herschel Walker from the Dallas Cowboys...

### N-COUNT

In astrology, a sign or a sign of the zodiac is one of the twelve areas into which the heavens are divided.  

> The New Moon takes place in your opposite sign of Libra on the 15th.

### PHRASE

If you say that there is no sign of someone, you mean that they have not yet arrived, although you are expecting them to come.  

> The London train was on time, but there was no sign of my Finnish friend.

### PHRASE

If you say that an agreement is signed and sealed, or signed, sealed and delivered, you mean that it is absolutely definite because everyone involved has signed all the legal documents.  

> The Chancellor had been hoping to have an agreement signed and sealed by the end of this week...



## 


