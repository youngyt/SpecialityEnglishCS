**carry**
(kæri)
VERB
If you carry something, you take it with you, holding it so that it does not touch the ground.
*He was carrying a briefcase.*