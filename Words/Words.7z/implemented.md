**implement**
**VERB**
If you implement something such as a plan, you ensure that what has been planned is done.
- _The government promised to implement a new system to control financial loan institutions._
- _If such measures were implemented, the problems could be overcome in twelve months._

 