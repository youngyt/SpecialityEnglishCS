---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["dedicated"]
---

# dedicated

## 发音

- ˈdedɪkeɪtɪd
- ˈdɛdɪˌketɪd

## 词义

### ADJ-GRADED

You use dedicated to describe someone who enjoys a particular activity very much and spends a lot of time doing it.  

> Her great-grandfather had clearly been a dedicated and stoical traveller.

### ADJ

You use dedicated to describe something that is made, built, or designed for one particular purpose or thing.  

> Such areas should also be served by dedicated cycle routes.



## 


