**issue** (ˈɪʃu ; Chiefly British ˈɪsju)

**countable noun**

An issue is an important subject that people are arguing about or discussing.

_Agents will raise the issue of prize-money for next year's world championships._

