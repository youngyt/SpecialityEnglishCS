---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["punctuation"]
---

# punctuation

## 发音

- ˌpʌŋktʃuˈeɪʃn
- ˌpʌŋktʃuˈeʃən

## 词义

### N-UNCOUNT

Punctuation is the use of symbols such as full stops or periods, commas, or question marks to divide written words into sentences and clauses.  

> He was known for his poor grammar and punctuation.

### N-UNCOUNT

Punctuation is the symbols that you use to divide written words into sentences and clauses.  

> Jessica scanned the lines, none of which had any punctuation.



## 


