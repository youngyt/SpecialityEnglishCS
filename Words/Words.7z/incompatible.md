---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["incompatible"]
---

# incompatible

## 发音

- ˌɪnkəmˈpætəbl
- ˌɪnkəmˈpætəbəl

## 词义

### ADJ

If one thing or person is incompatible with another, they are very different in important ways, and do not suit each other or agree with each other.  

> They feel strongly that their religion is incompatible with the political system... 

### ADJ

If one type of computer or computer system is incompatible with another, they cannot use the same programs or be linked up together.  

> This made its mini-computers incompatible with its mainframes...



## 


