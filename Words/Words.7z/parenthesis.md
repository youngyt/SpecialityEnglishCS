---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["parenthesis"]
---

# parenthesis

## 发音

- pəˈrenθəsɪs
- pəˈrɛnθɪsɪs

## 词义

### N-COUNT

Parentheses are a pair of curved marks that you put around words or numbers to indicate that they are additional, separate, or less important. (This sentence is in parentheses.)  

### N-COUNT

A parenthesis is a remark that is made in the middle of a piece of speech or writing, and which gives a little more information about the subject being discussed.  

### PHRASE

You say 'in parenthesis' to indicate that you are about to add something before going back to the main topic.  

> In parenthesis, I'd say that there were two aspects to writing you must never lose sight of.



## 


