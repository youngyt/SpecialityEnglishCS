---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["latch"]
---

# latch

## 发音

- lætʃ
- lætʃ

## 词义

### N-COUNT

A latch is a fastening on a door or gate. It consists of a metal bar which you lift in order to open the door.  

> You left the latch off the gate and the dog escaped.

### N-COUNT

A latch is a lock on a door which locks automatically when you shut the door, so that you need a key in order to open it from the outside.  

> ...a key clicked in the latch of the front door.

### VERB

If you latch a door or gate, you fasten it by means of a latch.  

> He latched the door, tested it, and turned around to speak to Frank.



## 


