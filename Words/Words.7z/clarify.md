---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["clarify"]
---

# clarify

## 发音

- ˈklærəfaɪ
- ˈklærəˌfaɪ

## 词义

### VERB

To clarify something means to make it easier to understand, usually by explaining it in more detail.  

> Thank you for writing and allowing me to clarify the present position...



## 


