**Exclusive** **OR-** (ɪkskluːsɪv ɔr)
**noun**
the connective that gives the value true to a disjunction if one or other, but not both, of the disjuncts are true
_Also called: exclusive disjunction. Compare inclusive or_