---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["instruction"]
---

# instruction

## 发音

- ɪnˈstrʌkʃn
- ɪnˈstrʌkʃən

## 词义

### N-COUNT

An instruction is something that someone tells you to do.  

> Two lawyers were told not to leave the building but no reason for this instruction was given.

### N-UNCOUNT

If someone gives you instruction in a subject or skill, they teach it to you.  

> Each candidate is given instruction in safety...

### N-PLURAL

Instructions are clear and detailed information on how to do something.  

> Always read the instructions before you start taking the medicine.



## 


