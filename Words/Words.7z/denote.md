**denote**
(dɪnoʊt)
**VERB**
If one thing denotes another, it is a sign or indication of it.[formal]
*Red eyes denote strain and fatigue. *