---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["devise","devised"]
---

# devise

## 发音

- dɪˈvaɪz
- dɪˈvaɪz

## 词义

### VERB

If you devise a plan, system, or machine, you have the idea for it and design it.  

> We devised a scheme to help him...



## 


