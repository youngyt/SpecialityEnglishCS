---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["corresponds"]
---

# corresponds

## 发音



## 词义

### Verb

(constructed with to) To be equivalent or similar in character, quantity, quality, origin, structure, function etc.

---

(constructed with with) to exchange messages, especially by postal letter, over a period of time.

> I've been corresponding with my German pen pal for three years.

---

To have sex with.



## 


