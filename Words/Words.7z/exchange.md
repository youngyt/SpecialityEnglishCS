---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["exchange"]
---

# exchange

## 发音

- ɪksˈtʃeɪndʒ
- ɪksˈtʃendʒ

## 词义

### V-RECIP

If two or more people exchange things of a particular kind, they give them to each other at the same time.  

> We exchanged addresses and Christmas cards...

### VERB

If you exchange something, you replace it with a different thing, especially something that is better or more satisfactory.  

> ...the chance to sell back or exchange goods...

### N-COUNT

An exchange is a brief conversation, usually an angry one.  

> There've been some bitter exchanges between the two groups.

### N-COUNT

An exchange of fire, for example, is an incident in which people use guns or missiles against each other.  

> There was an exchange of fire during which the gunman was wounded...

### N-COUNT

An exchange is an arrangement in which people from two different countries visit each other's country, to strengthen links between them.  

> ...a series of sporting and cultural exchanges with Seoul...

### N-IN-NAMES

Exchange is used in the names of some places where people used to trade and do business with each other.  

> ...the Royal Exchange.

### N-COUNT

The exchange is the same as the telephone exchange .  

### PHRASE

If you do or give something in exchange for something else, you do it or give it in order to get that thing.  

> It is illegal for public officials to solicit gifts or money in exchange for favors...



## 


