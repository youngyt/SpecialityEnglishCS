boot up

PHRASAL VERB When you **boot up** a computer, you make it ready to use by putting in the instructions which it needs in order to start working.启动（计算机）[COMPUTING]

-   I can boot up from a floppy disk, but that's all.[VP + _from/with_]
    
    我可以用一张软盘来启动，但其他的就无能为力了。
    
-   Go over to your PC and boot it up.[VERB noun PREP.]
    
    去启动你的个人电脑。
    

**SYN**start up, [prepare](x-dictionary:d:prepare), fire up, make ready