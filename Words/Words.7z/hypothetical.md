---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["hypothetical"]
---

# hypothetical

## 发音

- ˌhaɪpəˈθetɪkl
- ˌhaɪpəˈθɛtɪkəl

## 词义

### ADJ

If something is hypothetical, it is based on possible ideas or situations rather than actual ones.  

> Let's look at a hypothetical situation in which Carol, a recovering cocaine addict, gets invited to a party.



## 


