---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["manipulate","manipulating"]
---

# manipulate

## 发音

- məˈnɪpjuleɪt
- məˈnɪpjəˌlet

## 词义

### VERB

If you say that someone manipulates people, you disapprove of them because they skilfully force or persuade people to do what they want.  

> He is a very difficult character. He manipulates people...

### VERB

If you say that someone manipulates an event or situation, you disapprove of them because they use or control it for their own benefit, or cause it to develop in the way they want.  

> She was unable, for once, to control and manipulate events...

### VERB

If you manipulate something that requires skill, such as a complicated piece of equipment or a difficult idea, you operate it or process it.  

> The technology uses a pen to manipulate a computer...

### VERB

If someone manipulates your bones or muscles, they skilfully move and press them with their hands in order to push the bones into their correct position or make the muscles less stiff.  

> The way he can manipulate my leg has helped my arthritis so much.



## 


