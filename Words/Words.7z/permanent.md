---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["permanent"]
---

# permanent

## 发音

- ˈpɜ:mənənt
- ˈpɜrmənənt

## 词义

### ADJ

Something that is permanent lasts for ever.  

> Heavy drinking can cause permanent damage to the brain...

### ADJ

You use permanent to describe situations or states that keep occurring or which seem to exist all the time; used especially to describe problems or difficulties.  

> ...a permanent state of tension...

### ADJ

A permanent employee is one who is employed for an unlimited length of time.  

> At the end of the probationary period you will become a permanent employee.

### ADJ

Your permanent home or your permanent address is the one at which you spend most of your time or the one that you return to after having stayed in other places.  

> York Cottage was as near to a permanent home as the children knew...

### N-COUNT

A permanent is a treatment where a hair stylist curls your hair and treats it with a chemical so that it stays curly for several months.  



## 


