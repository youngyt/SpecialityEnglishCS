---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["initialize"]
---

# initialize

## 发音



## 词义

### Verb

To assign initial values to something

---

To assign an initial value to a variable

---

To format a storage medium prior to use

---

To prepare any hardware (such as a printer or scanner) for use



## 


