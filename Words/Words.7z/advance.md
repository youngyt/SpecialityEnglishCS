---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["advance"]
---

# advance

## 发音

- ədˈvɑ:ns
- ədˈvæns

## 词义

### VERB

To advance means to move forward, often in order to attack someone.  

> Reports from Chad suggest that rebel forces are advancing on the capital...

### VERB

See also:advanced;To advance means to make progress, especially in your knowledge of something.  

> Medical technology has advanced considerably...

### VERB

If you advance someone a sum of money, you lend it to them, or pay it to them earlier than arranged.  

> I advanced him some money, which he would repay on our way home...

### N-COUNT

An advance is money which is lent or paid to someone before they would normally receive it.  

> She was paid a £100,000 advance for her next two novels.

### VERB

To advance an event, or the time or date of an event, means to bring it forward to an earlier time or date.  

> Too much protein in the diet may advance the ageing process...

### VERB

If you advance a cause, interest, or claim, you support it and help to make it successful.  

> When not producing art of his own, Oliver was busy advancing the work of others.

### VERB

When a theory or argument is advanced, it is put forward for discussion.  

> Many theories have been advanced as to why some women suffer from depression...

### N-VAR

An advance is a forward movement of people or vehicles, usually as part of a military operation.  

> ...an advance on enemy positions...

### N-PLURAL

If you make advances to someone, you try to start a sexual relationship with them.  

> Mark had for some time been making advances towards her...

### N-VAR

An advance in a particular subject or activity is progress in understanding it or in doing it well.  

> Air safety has not improved since the dramatic advances of the 1970s...

### N-SING

If something is an advance on what was previously available or done, it is better in some way.  

> This could be an advance on the present situation.

### ADJ

Advance booking, notice, or warning is done or given before an event happens.  

> They don't normally give any advance notice about which building they're going to inspect...

### ADJ

An advance party or group is a small group of people who go on ahead of the main group.  

> The 20-strong advance party will be followed by another 600 soldiers as part of UN relief efforts.

### PREP-PHRASE

If one thing happens or is done in advance of another, it happens or is done before the other thing.  

> I had asked everyone to submit questions in advance of the meeting.

### PHRASE

If you do something in advance, you do it before a particular date or event.  

> The subject of the talk is announced a week in advance.



## 


