**multiplier**
(mʌltɪplaɪər)
COUNTABLE NOUN
When you multiply a number by another number, the second number is the multiplier.