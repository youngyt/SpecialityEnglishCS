**chunk**
(tʃʌŋk)
COUNTABLE NOUN
Chunks of something are thick solid pieces of it.
*They had to be careful of floating chunks of ice.*
*...a chunk of meat.*