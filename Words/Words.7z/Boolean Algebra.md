**algebra**  /ældʒɪbrə/
N-UNCOUNT
**Algebra** is a type of mathematics in which letters are used to represent possible quantities.