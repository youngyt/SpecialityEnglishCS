 **flip** (flɪp)

**verb**

If you flip a device on or off, or if you flip a switch, you turn it on or off by pressing the switch quickly.

_He didn't flip on the headlights until he was two blocks away._