---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["unbeatable"]
---

# unbeatable

## 发音

- ʌnˈbi:təbl
- ʌnˈbitəbəl

## 词义

### ADJ

If you describe something as unbeatable, you mean that it is the best thing of its kind.  

> These resorts, like Magaluf and Arenal, remain unbeatable in terms of price.

### ADJ

In a game or competition, if you describe a person or team as unbeatable, you mean that they win so often, or perform so well that they are unlikely to be beaten by anyone.  

> The opposition was unbeatable...



## 


