---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["colon"]
---

# colon

## 发音

- ˈkəʊlən
- ˈkoʊlən

## 词义

### N-COUNT

A colon is the  punctuation mark : which you can use in several ways. For example, you can put it before a list of things or before reported speech.  

### N-COUNT

Your colon is the part of your intestine above your rectum.  

> ...cancer of the colon.



## 


