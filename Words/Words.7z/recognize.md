---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["recognize"]
---

# recognize

## 发音

- <details><summary>/ˈɹɛkənaɪz/</summary><audio controls><source src="https://api.dictionaryapi.dev/media/pronunciations/en/recognize-uk.mp3"></audio></details>
- <details><summary>/ˈɹɛkənaɪz/</summary><audio controls><source src="https://api.dictionaryapi.dev/media/pronunciations/en/recognize-us.mp3"></audio></details>

## 词义

### Verb

To match (something or someone which one currently perceives) to a memory of some previous encounter with the same person or thing.

> I recognised his face immediately.

---

To acknowledge the existence or legality of; to treat as valid or worthy of consideration.

> The US and a number of EU countries are expected to recognize Kosovo on Monday.

---

(or with clause) To acknowledge or consider (as being a certain thing or having a certain quality or property).

> I recognize that my behaviour has been unacceptable.

---

To realize or discover the nature of something; apprehend quality in.

---

To show formal appreciation of, as with an award, commendation etc.

> His services were recognized in a testimonial.

---

To review; to examine again.

---

To reconnoiter.

---

To have the property to bind to specific antigens.



## 


