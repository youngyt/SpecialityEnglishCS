---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["temporarily"]
---

# temporarily

## 发音

- tempəˈrerɪlɪ
- tempəˈrerɪlɪ

## 词义

### ADJ

Something that is temporary lasts for only a limited time.  

> His job here is only temporary...



## 


