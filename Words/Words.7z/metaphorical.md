**metaphorical** (metəfɒrɪkəl , US -fɔːr-)

**adjective**

You use the word **metaphorical** to indicate that you are not using words with their ordinary meaning, but are describing something by means of an image or symbol.

-   *It turns out Levy is talking in metaphorical terms.*
	利维原来说的是一种比喻。
*   _The ship may be heading for the metaphoricalrocks unless a buyer can be found._ 
	除非可以找到买家，否则这条船也许就像朝着岩石撞过去一样下场悲惨。