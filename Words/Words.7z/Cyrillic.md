---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["Cyrillic", "Cyrillic characters"]
---

# Cyrillic

## 发音

- siˈrilik
- səˈrɪlɪk

## 词义

### ADJ

The Cyrillic alphabet is the alphabet that is used to write some Slavonic languages, such as Russian and Bulgarian.  

### N-UNCOUNT

Cyrillic is the Cyrillic alphabet.  

> ...signs written in Cyrillic.



## 


