PHRASEIf you do something **from scratch**, you do it without making use of anything that has been done before.从零开始；从头做起；白手起家

-   Building a home from scratch can be both exciting and challenging.
    
    建立一个全新的家庭既让人兴奋又富于挑战。
    
-   Hong Kong's manufacturing industry did not start from scratch in the post-war period. 
    
    战后，香港制造业的兴起并非从零开始。