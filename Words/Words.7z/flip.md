---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["flip"]
---

# flip

## 发音

- flɪp
- flɪp

## 词义

### VERB

If you flip a device on or off, or if you flip a switch, you turn it on or off by pressing the switch quickly.  

> He didn't flip on the headlights until he was two blocks away...

### VERB

If you flip through the pages of a book, for example, you quickly turn over the pages in order to find a particular one or to get an idea of the contents.  

> He was flipping through a magazine in the living room...

### V-ERG

If something flips over, or if you flip it over or into a different position, it moves or is moved into a different position.  

> The plane then flipped over and burst into flames...

### VERB

If you flip something, especially a coin, you use your thumb to make it turn over and over, as it goes through the air.  

> I pulled a coin from my pocket and flipped it...

### VERB

If someone flips, they suddenly become extremely upset or angry because of something that has happened.  

> He got so provoked that he flipped.

### ADJ-GRADED

If you say that someone is being flip, you disapprove of them because you think that what they are saying shows they are not being serious enough about something.  

> ...a flip answer...



## 


