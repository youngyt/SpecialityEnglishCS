entire  /ɛnˈtaɪr/

ADJYou use **entire** when you want to emphasize that you are referring to the whole of something, for example, the whole of a place, time, or population.全部的；整个的[EMPHASIS]

-   He had spent his entire life in China as a doctor.
    
    他一生都在中国当医生。