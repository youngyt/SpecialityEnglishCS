---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["sequence"]
---

# sequence

## 发音

- ˈsi:kwəns
- ˈsikwəns, -ˌkwɛns

## 词义

### N-COUNT

A sequence of events or things is a number of events or things that come one after another in a particular order.  

> ...the sequence of events which led to the murder.

### N-COUNT

A particular sequence is a particular order in which things happen or are arranged.  

> ...the colour sequence yellow, orange, purple, blue, green and white...

### N-COUNT

A film sequence is a part of a film that shows a single set of actions.  

> The best sequence in the film occurs when Roth stops at a house he used to live in.

### N-COUNT

A gene sequence or a DNA sequence is the order in which the elements making up a particular gene are combined.  

> The project is nothing less than mapping every gene sequence in the human body.



## 


