**scale**
(skeɪl)
 SINGULAR NOUN
If you refer to the scale of something, you are referring to its size or extent, especially when it is very big.
*However, he underestimates the scale of the problem. *