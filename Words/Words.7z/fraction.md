---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["fraction"]
---

# fraction

## 发音

- ˈfrækʃn
- ˈfrækʃən

## 词义

### N-COUNT

A fraction of something is a tiny amount or proportion of it.  

> She hesitated for a fraction of a second before responding...

### N-COUNT

A fraction is a number that can be expressed as a proportion of two whole numbers. For example, ½ and ⅓ are both fractions.  

> The students had a grasp of decimals, percentages and fractions.



## 


