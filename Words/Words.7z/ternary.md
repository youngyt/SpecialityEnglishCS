**ternary** (ˈtɜːrnəri) (noun plural -ries)

**Adjective**

consisting of three or groups of three