---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["current"]
---

# current

## 发音

- ˈkʌrənt
- ˈkɜrənt

## 词义

### N-COUNT

A current is a steady and continuous flowing movement of some of the water in a river, lake, or sea.  

> Under normal conditions, the ocean currents of the tropical Pacific travel from east to west...

### N-COUNT

A current is a steady flowing movement of air.  

> I felt a current of cool air blowing in my face.

### N-COUNT

An electric current is a flow of electricity through a wire or circuit.  

> A powerful electric current is passed through a piece of graphite.

### N-COUNT

A particular current is a particular feeling, idea, or quality that exists within a group of people.  

> Each party represents a distinct current of thought...

### ADJ

Current means happening, being used, or being done at the present time.  

> The current situation is very different to that in 1990...

### ADJ

Ideas and customs that are current are generally accepted and used by most people.  

> Current thinking suggests that toxins only have a small part to play in the build up of cellulite...



## 


