---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["module"]
---

# module

## 发音

- /ˈmɒdjuːl/
- /ˈmɑdʒuːl/

## 词义

### Noun

A self-contained component of a system, often interchangeable, which has a well-defined interface to the other components.

---

A standard unit of measure used for determining the proportions of a building.

---

A section of a program; a subroutine or group of subroutines.

---

A unit of education covering a single topic.

> Which modules are you studying next year?

---

A pre-prepared adventure scenario with related materials for a role-playing game.

---

An abelian group equipped with the operation of multiplication by an element of a ring (or another of certain algebraic objects), representing a generalisation of the concept of vector space with scalar multiplication.

---

(fractal geometry) A fractal element.

---

A file containing a music sequence that can be played in a tracker (called also mod or music module).

---

(hydraulics) A contrivance for regulating the supply of water from an irrigation channel.

---

An independent self-contained unit of a spacecraft.



## 


