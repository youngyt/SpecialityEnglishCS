#waitingforlove #avicii
# Waiting for Love
## Background
 "Waiting for Love" is a song by Swedish DJ and music producer Avicii, produced by Avicii and Dutch producer *Martin Garrix* and ==featuring uncredited vocals== from *Simon Aldred*, the former lead singer of English band Cherry Ghost. The track was released on 22 May 2015 as the lead single from Avicii's second studio album, **Stories** (2015). The lyrics were also written by Aldred.
## Lyrics
Where there's a will, there's a way, kind of beautiful
And every night has its day, so magical
And if there's love in this life, there's no obstacle
That can't be defeated

For every tyrant a tear for the vulnerable
In every lost soul the bones of a miracle
For every dreamer a dream we're unstoppable
With something to believe in

Monday left me broken
Tuesday I was through with hoping
Wednesday my empty arms were open
Thursday waiting for love, waiting for love
Thank the stars it's Friday
I'm burning like a fire gone wild on Saturday
Guess I won't be coming to church on Sunday
I'll be waiting for love, waiting for love
To come around

We are one of a kind irreplaceable
How did I get so blind and so cynical
If there's love in this life we're unstoppable
No we can't be defeated

Monday left me broken
Tuesday I was through with hoping
Wednesday my empty arms were open
Thursday waiting for love, waiting for love
Thank the stars it's Friday
I'm burning like a fire gone wild on Saturday
Guess I won't be coming to church on Sunday
I'll be waiting for love, waiting for love
To come around