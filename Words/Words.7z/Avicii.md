# Biography
**Tim Bergling** (Swedish: [[ˈtɪmː ˈbæ̂rjlɪŋ]]  8 September 1989 – 20 April 2018), known professionally as **Avicii**([/əˈviːtʃi/]), was a Swedish DJ, remixer, record producer, musician and songwriter.
