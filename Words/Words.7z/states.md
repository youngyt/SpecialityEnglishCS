---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["state"]
---

# state

## 发音

- steɪt
- stet

## 词义

### N-COUNT

You can refer to countries as states, particularly when you are discussing politics.  →see usage note at:country

> Mexico is a secular state and does not have diplomatic relations with the Vatican...

### N-COUNT

Some large countries such as the USA are divided into smaller areas called states .  

> Leaders of the Southern states are meeting in Louisville.

### N-PROPER

The USA is sometimes referred to as the States .  

### N-SING

You can refer to the government of a country as the state .  

> The state does not collect enough revenue to cover its expenditure...

### ADJ

State industries or organizations are financed and organized by the government rather than private companies.  →see: state school; 

> ...reform of the state social-security system.

### ADJ

A state occasion is a formal one involving the head of a country.  

> ...the Queen's three-day state visit to France.

### N-COUNT

When you talk about the state of someone or something, you are referring to the condition they are in or what they are like at a particular time.  

> For the first few months after Daniel died, I was in a state of clinical depression...

### VERB

If you state something, you say or write it in a formal or definite way.  

> Clearly state your address and telephone number... 

### PHRASE

If you say that someone is not in a fit state to do something, you mean that they are too upset or ill to do it.  

> When you left our place, you weren't in a fit state to drive.

### PHRASE

If you are in a state or if you get into a state, you are very upset or nervous about something.  

> I was in a terrible state because nobody could understand why I had this illness...

### PHRASE

If the dead body of an important person lies in state, it is publicly displayed for a few days before it is buried.  



## 


