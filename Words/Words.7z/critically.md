---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["critically"]
---

# critically

## 发音

- 'krɪtɪklɪ
- ˈkrɪtɪklɪ

## 词义

### ADJ-GRADED

A critical time, factor, or situation is extremely important.  

> The incident happened at a critical point in the campaign... 

### ADJ

A critical situation is very serious and dangerous.  

> The German authorities are considering an airlift if the situation becomes critical...

### ADJ

If a person is critical or in a critical condition in hospital, they are seriously ill.  

> Ten of the injured are said to be in critical condition.

### ADJ-GRADED

To be critical of someone or something means to criticize them.  

> His report is highly critical of the trial judge...

### ADJ

A critical approach to something involves examining and judging it carefully.  

> We need to become critical text-readers...

### ADJ

If something or someone receives critical acclaim, critics say that they are very good.  

> The film met with considerable critical and public acclaim...



## 


