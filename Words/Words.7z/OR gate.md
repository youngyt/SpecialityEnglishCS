**OR gate** (ɔr geɪt)
**noun**
An OR gate is a digital logic gate that gives an output of 1 when any of its inputs are 1, otherwise 0