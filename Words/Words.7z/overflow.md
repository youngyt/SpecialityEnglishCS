---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["overflow"]
---

# overflow

## 发音

- ˌəʊvəˈfləʊ
- ˌoʊvərˈfloʊ

## 词义

### VERB

If a liquid or a river overflows, it flows over the edges of the container or place it is in.  

> Pour in some of the syrup, but not all of it, as it will probably overflow...

### VERB

If a place or container is overflowing with people or things, it is too full of them.  

> The great hall was overflowing with people...

### VERB

If someone is overflowing with a feeling or if the feeling overflows, the person is experiencing it very strongly and shows this in their behaviour.  

> Kenneth overflowed with friendliness and hospitality...

### N-COUNT

The overflow is the extra people or things that something cannot contain or deal with because it is not large enough.  

> Tents have been set up next to hospitals to handle the overflow...

### N-COUNT

An overflow is a hole or pipe through which liquid can flow out of a container when it gets too full.  

> ...the overflow pipe.

### PHRASE

If a place or container is filled to overflowing, it is so full of people or things that no more can fit in.  

> The kitchen garden was full to overflowing with fresh vegetables...



## 


