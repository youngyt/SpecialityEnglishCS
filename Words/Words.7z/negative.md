---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["negative"]
---

# negative

## 发音

- ˈnegətɪv
- ˈnɛɡətɪv

## 词义

### ADJ-GRADED

A fact, situation, or experience that is negative is unpleasant, depressing, or harmful.  

> The news from overseas is overwhelmingly negative...

### ADJ-GRADED

If someone is negative or has a negative attitude, they consider only the bad aspects of a situation, rather than the good ones.  

> When asked for your views about your current job, on no account must you be negative about it...

### ADJ

A negative reply or decision indicates the answer 'no'.  

> Dr Velayati gave a vague but negative response...

### N-COUNT

A negative is a word, expression, or gesture that means 'no' or 'not'.  

> In the past we have heard only negatives when it came to following a healthy diet.

### ADJ

In grammar, a negative clause contains a word such as 'not', 'never', or 'no-one'.  

### ADJ

If a medical test or scientific test is negative, it shows no evidence of the medical condition or substance that you are looking for.  

> So far 57 have taken the test and all have been negative.

### N-COUNT

In photography, a negative is an image that shows dark areas as light and light areas as dark. Negatives are made from a camera film, and are used to print photographs.  

### ADJ

A negative charge or current has the same electrical charge as an electron.  

> Stimulate the site of greatest pain with a small negative current.

### ADJ

A negative number, quantity, or measurement is less than zero.  

> The weakest students can end up with a negative score.

### PHRASE

If an answer is in the negative, it is 'no' or means 'no'.  

> The Council answered those questions in the negative...

### PHRASE

If a sentence is in the negative, it contains a word such as 'not', 'never', or 'no-one'.  

> 'I went' in the negative is 'I did not go'.



## 


