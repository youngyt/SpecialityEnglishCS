 **modify** (ˈmɑdəˌfaɪ)

**verb**

If you modify something, you change it slightly, usually in order to improve it.

_The club members did agree to modify their recruitment policy._
