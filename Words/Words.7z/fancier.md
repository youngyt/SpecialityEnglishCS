---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["fancy"]
---

# fancy

## 发音

- ˈfænsi
- ˈfænsi

## 词义

### VERB

If you fancy something, you want to have it or to do it.  

> What do you fancy doing, anyway?...

### N-COUNT

A fancy is a liking or desire for someone or something, especially one that does not last long.  

> She did not suspect that his interest was just a passing fancy.

### VERB

If you fancy someone, you feel attracted to them, especially in a sexual way.  

> The boys would tease you to death if they didn't fancy you...

### VERB

If you fancy yourself as a particular kind of person or fancy yourself doing a particular thing, you like the idea of being that kind of person or doing that thing.  

> So you fancy yourself as the boss someday?...

### VERB

If you say that someone fancies themselves (as) a particular kind of person, you mean that they think, often wrongly, that they have the good qualities which that kind of person has.  

> She fancies herself a bohemian...

### VERB

If you say that you fancy a particular competitor or team in a competition, you think they will win.  

> You have to fancy Bath because they are the most consistent team in England...

### VERB

If you fancy that something is the case, you think or suppose that it is so.  

> When Ferris looked up he fancied that he saw a shadow pass close to the window...

### N-VAR

A fancy is an idea that is unlikely, untrue, or imaginary.  

> His last book is a bold, at times surrealistic mixture of fact and fancy.

### EXCLAM

You say 'fancy' or 'fancy that' when you want to express surprise or disapproval.  

> It was very tasteless. Fancy talking like that so soon after his death...

### PHRASE

If you take a fancy to someone or something, you start liking them, usually for no understandable reason.  

> Sylvia took quite a fancy to him...

### PHRASE

If something takes your fancy or tickles your fancy, you like it a lot when you see it or think of it.  

> She makes most of her own clothes, copying any fashion which takes her fancy.

### ADJ-GRADED

If you describe something as fancy, you mean that it is special, unusual, or elaborate, for example because it has a lot of decoration.  

> It was packaged in a fancy plastic case with attractive graphics.

### ADJ-GRADED

If you describe something as fancy, you mean that it is very expensive or of very high quality, and you often dislike it because of this.  

> He owned a fancy house out on Lake Agawam...



## 


