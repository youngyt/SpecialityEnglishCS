PHRASAL VERBTo **lay out** ideas, principles, or plans means to explain or present them clearly, for example in a document or a meeting.阐述；讲解；说明

-   Maxwell listened closely as Johnson laid out his plan.[VERBPREP. noun]
    
    马克斯韦尔仔细听着约翰逊讲解其计划。
    
-   Cuomo laid it out in simple language.[VERB noun PREP.]
    
    科莫用简单的语言作了解释。
    

**SYN** [present](x-dictionary:d:present), [explain](x-dictionary:d:explain), [describe](x-dictionary:d:describe), [show](x-dictionary:d:show)