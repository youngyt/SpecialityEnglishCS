---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["underlie"]
---

# underlie

## 发音

- ˌʌndəˈlaɪ
- ˌʌndərˈlaɪ

## 词义

### VERB

See also:underlying;If something underlies a feeling or situation, it is the cause or basis of it.  

> Try to figure out what feeling underlies your anger.



## 


