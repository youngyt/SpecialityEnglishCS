**evaluate**  (iˈvæljuˌeɪt)
evaluates, evaluating, evaluated
VERB
If you **evaluate** something or someone, you consider them in order to make a judgment about them, for example about how good or bad they are.
*They will first send in trained nurses to evaluate the needs of the individual situation.*