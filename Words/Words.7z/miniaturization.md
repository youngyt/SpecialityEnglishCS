---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["miniaturization"]
---

# miniaturization

## 发音

- ˌmɪnətʃəraɪ'zeɪʃn
- ˌmɪnətʃəraɪ'zeɪʃn

## 词义

### VERB

If you miniaturize something such as a machine, you produce a very small version of it.  

> ...the problems of further miniaturizing the available technologies.



## 


