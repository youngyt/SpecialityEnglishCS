---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["lay"]
---

# lay

## 发音

- leɪ
- le

## 词义

### VERB

If you lay something somewhere, you put it there in a careful, gentle, or neat way.  

> Lay a sheet of newspaper on the floor...

### VERB

If you lay the table or lay the places at a table, you arrange the knives, forks, and other things that people need on the table before a meal.  

> The butler always laid the table.

### VERB

If you lay something such as carpets, cables, or foundations, you put them into their permanent position.  

> A man came to lay the saloon carpet...

### VERB

To lay a trap means to prepare it in order to catch someone or something.  

> They were laying a trap for the kidnapper.

### VERB

When a female bird lays an egg, it produces an egg by pushing it out of its body.  

> My canary has laid an egg...

### VERB

Lay is used with some nouns to talk about making official preparations for something. For example, if you lay the basis for something or lay plans for it, you prepare it carefully.  

> Diplomats meeting in Chile have laid the groundwork for far-reaching environmental regulations...

### VERB

Lay is used with some nouns in expressions about accusing or blaming someone. For example, if you lay the blame for a mistake on someone, you say it is their fault, or if the police lay charges against someone, they officially accuse that person of a crime.  

> She refused to lay the blame on any one party...

### VERB

If you say that you would lay bets, odds, or money on something happening, you mean that you are very confident that it will happen.  

> I wouldn't  lay bets on his still remaining manager after the spring...

### VERB

To lay someone means to have sex with them.  

### N-COUNT

Lay is used in expressions such a good lay or an easy lay to describe what someone is like as a sexual partner.  

### PHRASE

If someone is laying it on thick or is laying it on, they are exaggerating a statement, experience, or emotion in order to try to impress people.  

> Don't lay it on too thick, but make sure they are flattered...

### PHRASE

If you lay yourself open to criticism or attack, or if something lays you open to it, something you do makes it possible or likely that other people will criticize or attack you.  

> The party thereby lays itself open to charges of conflict of interest...

### ADJ

You use lay to describe people who are involved with a Christian church but are not members of the clergy or are not monks or nuns.  

> Edwards is a Methodist lay preacher and social worker.

### ADJ

You use lay to describe people who are not experts or professionals in a particular subject or activity.  

> It is difficult for a lay person to gain access to medical libraries...



## 


