---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["conveniently"]
---

# conveniently

## 发音

- kən'vi:njəntlɪ
- kənˈvinjəntlɪ

## 词义

### ADJ-GRADED

If a way of doing something is convenient, it is easy, or very useful or suitable for a particular purpose.  

> ...a flexible and convenient way of paying for business expenses...

### ADJ-GRADED

If you describe a place as convenient, you are pleased because it is near to where you are, or because you can reach another place from there quickly and easily.  

> The town is well placed for easy access to London and convenient for Heathrow Airport...

### ADJ-GRADED

A convenient time to do something, for example to meet someone, is a time when you are free to do it or would like to do it.  

> She will try to arrange a mutually convenient time and place for an interview...

### ADJ-GRADED

If you describe someone's attitudes or actions as convenient, you think they are only adopting those attitudes or performing those actions in order to avoid something difficult or unpleasant.  

> We cannot make this minority a convenient excuse to turn our backs...



## 


