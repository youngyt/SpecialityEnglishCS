**incredible** (ɪnkredɪbəl)
**ADJ-GRADED**
If you describe something or someone as **incredible**, you like them very much or are impressed by them, because they are extremely or unusually good.
*The wildflowers will be incredible after this rain.*