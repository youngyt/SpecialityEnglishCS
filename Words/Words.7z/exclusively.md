**exclusively**  (ɪkskluːsɪvli)
ADV[ADVERB with verb] 

**Exclusively** is used to refer to situations or activities that involve only the thing or things mentioned, and nothing else.排他地；独占地；专有地；完全地

-   ...an exclusively male domain.   
      
-   Instruction in these subjects in undergraduate classes is almost exclusively by lecture.     

**SYN** [solely](x-dictionary:d:solely), [totally](x-dictionary:d:totally), [fully](x-dictionary:d:fully), [entirely](x-dictionary:d:entirely)