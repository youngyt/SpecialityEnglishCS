**XOR** (ˈeksˌɔr)
**noun**
a Boolean operator that returns a positive result when either but not both of its operands are positive