---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["increment"]
---

# increment

## 发音

- ˈɪŋkrəmənt
- ˈɪnkrəmənt, ˈɪŋ-

## 词义

### N-COUNT

An increment in something or in the value of something is an amount by which it increases.  

> The average yearly increment in labour productivity in industry was 4.5 per cent...

### N-COUNT

An increment is an amount by which your salary automatically increases after a fixed period of time.  

> Many teachers qualify for an annual increment.



## 


