---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["gobbledygook"]
---

# gobbledygook

## 发音



## 词义

### Noun

Nonsense; meaningless or encrypted language.

---

Something written in an overly complex, incoherent, or incomprehensible manner.



## 


