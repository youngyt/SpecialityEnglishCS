**distinct** (dɪˈstɪŋkt)

**Adjective**

not alike; different

_His private and public lives are distinct._