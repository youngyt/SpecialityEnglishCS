---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["glitch"]
---

# glitch

## 发音

- glɪtʃ
- ɡlɪtʃ

## 词义

### N-COUNT

A glitch is a problem which stops something from working properly or being successful.  

> Manufacturing glitches have limited the factory's output.



## 


