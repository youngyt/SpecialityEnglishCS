---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["mutually"]
---

# mutually

## 发音

- ˈmju:tʃuəli
- ˈmjuːtʃuəli

## 词义

### ADJ

You use mutual to  describe a situation, feeling, or action that is experienced, felt, or done by both of two people mentioned.  

> The East and the West can work together for their mutual benefit and progress...

### ADJ

You use mutual to describe something such as an interest which two or more people share.  

> They do, however, share a mutual interest in design...

### ADJ

If a building society or an insurance company has mutual status, it is not owned by shareholders but by its customers, who receive a share of the profits.  

> Britain's third largest building society abandoned its mutual status and became a bank.



## 


