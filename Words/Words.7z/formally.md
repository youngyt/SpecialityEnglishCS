 **formally** (ˈfɔrməli)

**adverb** 

in a formal manner