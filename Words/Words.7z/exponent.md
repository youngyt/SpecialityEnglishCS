---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["exponent"]
---

# exponent

## 发音

- ɪkˈspəʊnənt
- ɪkˈspoʊnənt

## 词义

### N-COUNT

An exponent of an idea, theory, or plan is a person who supports and explains it, and who tries to persuade other people that it is a good idea.  

> ...a leading exponent of test-tube baby techniques.

### N-COUNT

An exponent of a particular skill or activity is a person who is good at it.  

> ...the great exponent of expressionist dance, Kurt Jooss.



## 


