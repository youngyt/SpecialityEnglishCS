**AND gate** (ænd geɪt)
**noun**
An AND gate is an electrical circuit that combines two signals so that the output is on if both signals are present.
_The output of the AND gate is connected to a base driver which is coupled to the bases of transistors, and alternately switches the transistors at opposite corners of the inverter._