---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["positive"]
---

# positive

## 发音

- ˈpɒzətɪv
- ˈpɑzətɪv

## 词义

### ADJ-GRADED

If you are positive  about things, you are hopeful and confident, and think of the good aspects of a situation rather than the bad ones.  

> Be positive about your future and get on with living a normal life...

### ADJ-GRADED

A positive fact, situation, or experience is pleasant and helpful to you in some way.  

> The parting from his sister had a positive effect on John...

### ADJ-GRADED

If you make a positive decision or take positive action, you do something definite in order to deal with a task or problem.  

> There are positive changes that should be implemented in the rearing of animals...

### ADJ-GRADED

A positive response to something indicates agreement, approval, or encouragement.  

> There's been a positive response to the UN Secretary-General's recent peace efforts.

### ADJ-GRADED

If you are positive about something, you are completely sure about it.  

> I'm as positive as I can be about it...

### ADJ

Positive evidence gives definite proof of the truth or identity of something.  

> There was no positive evidence that any birth defects had arisen as a result of Vitamin A intake.

### ADJ

If a medical or scientific test is positive, it shows that something has happened or is present.  HIV positive→see: HIV; 

> If the test is positive, a course of antibiotics may be prescribed...

### ADJ

See also:positively;You can use positive to emphasize a noun.  

> Good day to you, Bernard! It's a positive delight to see you...

### ADJ

A positive number is greater than zero.  

> It's really a simple numbers game with negative and positive numbers.

### ADJ

If something has a positive electrical charge, it has the same charge as a proton and the opposite charge to an electron.  



## 


