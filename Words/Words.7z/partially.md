---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["partially"]
---

# partially

## 发音

- ˈpɑ:ʃəli
- ˈpɑrʃəli

## 词义

### ADV

If something happens or exists partially, it happens or exists to some extent, but not completely.  

> Lisa is deaf in one ear and partially blind.



## 


