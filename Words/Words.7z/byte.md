**byte**
(baɪt)
NOUN computing
a group of bits, usually eight, processed as a single unit of data.