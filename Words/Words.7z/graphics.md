**graphics**
(græfɪk)
N-UNCOUNT
**Graphics** is the activity of drawing or making pictures, especially in publishing, industry, or computing.
*...a computer manufacturer which specializes in graphics. *