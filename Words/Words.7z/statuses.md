---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["status"]
---

# status

## 发音

- ˈsteɪtəs
- ˈstetəs, ˈstætəs

## 词义

### N-UNCOUNT

Your status is your social or professional position.  

> People of higher status tend more to use certain drugs. 

### N-UNCOUNT

Status is the importance and respect that someone has among the public or a particular group.  

> Nurses are undervalued, and they never enjoy the same status as doctors...

### N-UNCOUNT

The status of something is the importance that people give it.  

> Those things that can be assessed by external tests are being given unduly high status...

### N-UNCOUNT

A particular status is an official description that says what category a person, organization, or place belongs to, and gives them particular rights or advantages.  

> Bristol regained its status as a city in the local government reorganisation. 

### N-UNCOUNT

The status of something is its state of affairs at a particular time.  

> The Council unanimously directed city staff to prepare a status report on the project...



## 


