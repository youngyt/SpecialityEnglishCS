---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["downside"]
---

# downside

## 发音

- ˈdaʊnsaɪd
- ˈdaʊnˌsaɪd

## 词义

### N-SING

The downside of a situation is the aspect of it which is less positive, pleasant, or useful than its other aspects.  

> The downside of this approach is a lack of clear leadership...



## 


