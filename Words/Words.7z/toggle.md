---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["toggle"]
---

# toggle

## 发音

- ˈtɒgl
- ˈtɑgl

## 词义

### N-COUNT

A toggle is a small piece of wood or plastic which is sewn to something such as a coat or bag, and which is pushed through a loop or hole to fasten it.  



## 


