---
# 由 Obsidian Dictionary Plugin 插件自动生成
aliases: ["frequency"]
---

# frequency

## 发音

- ˈfri:kwənsi
- ˈfrikwənsi

## 词义

### N-UNCOUNT

The frequency of an event is the number of times it happens during a particular period.  

> The frequency of Kara's phone calls increased rapidly...

### N-VAR

In physics, the frequency of a sound wave or a radio wave is the number of times it vibrates within a specified period of time.  

> You can't hear waves of such a high frequency.



## 


